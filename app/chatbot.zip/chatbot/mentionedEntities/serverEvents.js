// chatbot/serverEvents.js

const express = require('express');
const { databaseName, mongoClient } = require('../../utils/mongoClient');

const MONGO_TABLE_THINGS = 'things';
const clients = new Set();

const app = express();

// const db = mongoClient.db(databaseName);
// const thingsCollection = db.collection(MONGO_TABLE_THINGS);

// app.use(express.json());

// app.get('/events', (req, res) => {
//   res.setHeader('Content-Type', 'text/event-stream');
//   res.setHeader('Cache-Control', 'no-cache');
//   res.setHeader('Connection', 'keep-alive');
//   res.flushHeaders();

//   clients.add(res);

//   req.on('close', () => {
//     clients.delete(res);
//   });
// });

// function pushUpdates(things) {
//   const data = `data: ${JSON.stringify(things)}\n\n`;
//   clients.forEach(client => {
//     if (!client.headersSent) {
//       client.write(data);
//     }
//   });
// }

// async function saveThings(things) {
//   try {
//     await thingsCollection.insertMany(things);
//     pushUpdates(things);
//   } catch (err) {
//     console.error('Error saving things:', err);
//   }
// }

// async function getThings() {
//   try {
//     return await thingsCollection.find({}).toArray();
//   } catch (err) {
//     console.error('Error getting things:', err);
//     return [];
//   }
// }

module.exports = {
  app,
  // saveThings,
  // getThings
};
