const { OpenAI } = require('openai');

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

const getChatGPTResponse = async (userMessage) => {
  try {
    const response = await openai.chat.completions.create({
      messages: [{ role: 'user', content: userMessage }],
      model: 'gpt-3.5-turbo',
    });

    return response?.choices[0]?.message?.content;
  } catch (error) {
    console.error('Error communicating with OpenAI API:', error);
    throw new Error('Error communicating with OpenAI API');
  }
};

const sendMessageToCincoBot = async (io, socket, msg, event) => {
  const userMessage = msg.replace('@computer', '').trim();
  try {
    const aiMessage = await getChatGPTResponse(userMessage);
    io.emit(event, { text: `Cinco bot: ${aiMessage}`, ...msg });
    console.log('aiMessage', aiMessage);
  } catch (error) {
    io.emit(event, { text: 'Cinco bot: Sorry, there was an error processing your request.', ...msg });
  }
};

module.exports = { sendMessageToCincoBot };
